<?php 
require __DIR__.'/../boot/boot.php';


use Hotel\Room;
use Hotel\Favorite;
use Hotel\User;
use Hotel\Review;
use Hotel\Booking;



//initialize Room service
$room = new Room;
//$roomType = new RoomType;
$favorite = new Favorite;

//Check for room id
$roomId = $_REQUEST['room_id'];
if(empty($roomId)){
    header('Location: landing_page.php');
    return;
}

//Load room info
$roomInfo = $room->get($roomId);

if(empty($roomInfo)) {
    header('Location: landing_page.php');
    return;
}
// //load room type info
// $roomTypeInfo = $roomType->get($roomId);

//Get current user id
$userId = User::getCurrentUserId();

//Check if room is favorite for current user
$isFavorite = $favorite->isFavorite($roomId, $userId);

//Load all room reviews
$review = new Review();
$allReviews = $review->getReviewsByRoom($roomId);

//Check for booking room
$checkInDate = $_REQUEST['check_in_date'];
$checkOutDate = $_REQUEST['check_out_date'];



$alreadyBooked = empty($checkInDate) || empty($checkOutDate);
if(!$alreadyBooked){
    //Look for bookings
    $booking = new Booking();
    $alreadyBooked = $booking->isBooked($roomId,$checkInDate, $checkOutDate);

}



?>



<!DOCTYPE>
<html>
   <head>
     <meta charset="UTF-8">
     <meta name="viewport" content="width=device-width initial-scale=1.0">
     <meta name="robots" content="noindex,nofollow">
     <title>CollegeLink Project|Room Page</title>
   </head>
   <body>
      <header>
         <section class="menu">
           <div class="left_menu">
             <p>Hotels</p>
           </div>
             <div class="right_menu">
                <a href="index.html">
                  <i class="fas fa-home"></i>
                  Home
                </a>
                <div class="profile">
                  <a href="profile.html">
                     <i class="fas fa-user-alt"></i>
                     Profile
                  </a>
                </div>
             </div>
         </section>
      </header>
      </body>
      <main>
         <div class="container">
            <section class="hotel-details">
              <header>
                <div class="left-h">
                   <h3>Hotel Grande Bretagne - Athens,Syntagma square |</h3>
                   <span>Reviews:</span>
                   <span class="check"><i class="fas fa-star"></i></span>
                   <span class="check"><i class="fas fa-star"></i></span>
                   <span class="check"><i class="fas fa-star"></i></span>
                   <span class="check"><i class="fas fa-star"></i></span>
                   <span class="check"><i class="fas fa-star"></i></span>|
                   <i class="fas fa-heart"></i>
                 </div>
                <div class="right-h">
                    <p>per night: 500€</p>
                </div>
              </header>
            </section>
            <img style="margin-top: 20px;" src="assets/images/room-2.jpg"
             alt="Photo of Grande Bretagne Hotel's room"
             width="60%"
             height="auto">
            <div class="room-details">
              <ul class="text-c">
                <li>
                  <span>
                    <i class="fas fa-user-alt"></i> 2
                  </span> <br>
                  <span>count of guests</span>
                </li>
                <li>
                  <span>
                    <i class="fas fa-bed"></i> 2
                  </span> <br>
                  <span>type of room</span>
                </li>
                <li>
                  <span>
                    <i class="fas fa-parking"></i> 1
                  </span> <br>
                  <span>parking</span>
                </li>
                <li>
                  <span>
                    <i class="fas fa-signal"></i> Yes
                  </span> <br>
                  <span>wifi</span>
                </li>
                <li>
                  <span>
                    <i class="fas fa-paw"></i> Yes
                  </span> <br>
                  <span>pet friendly</span>
                </li>
              </ul>
            </div>
            <section class="room-description">
            <div class="title">
                <h4>room description</h4>
            </div>
            <div class="room-info">
                <p>Το αρχοντικό αυτό δωμάτιο είναι διακοσμημένο με άριστης ποιότητας έπιπλα. Στο μαρμάρινο μπάνιο θα βρείτε πάγκο καλλωπισμού, ξεχωριστή μπανιέρα και ντους. 
                  Διαθέτει μπαλκόνι με θέα στην Ακρόπολη, από όπου μπορείτε να παρακολουθήσετε την καθημερινή αλλαγή φρουράς στο κτήριο της Βουλής.
                </p>
            </div>
          </section>
          <div class="book">
              <a href="profile.html"><button>Book now</button></a>
          </div>
          <div class="iframe">
              <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3145.0405830471623!2d23.7331236148158!3d37.97618220831995!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x14a1bd4b45322381%3A0xb126665c4705d54b!2sHotel%20Grande%20Bretagne%2C%20a%20Luxury%20Collection%20Hotel%2C%20Athens!5e0!3m2!1sel!2sgr!4v1629379093773!5m2!1sel!2sgr
              " width="100%" height="50%" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
          </div>
          <section>
             <div class="reviews">
                <h3>Reviews</h3>
                <h4>1. username_n1
                <span class="check"><i class="fas fa-star"></i></span>
                <span class="check"><i class="fas fa-star"></i></span>
                <span class="check"><i class="fas fa-star"></i></span>
                <span class="check"><i class="fas fa-star"></i></span>
                <span><i class="fas fa-star"></i></span>
              </h4>
              <span>Add time: 2021-10/19</span>
              <p>This is an amazing hotel!</p>
             </div>
             <div class="add-review">
                <h3>Add review</h3>
                <span class="check"><i class="fas fa-star"></i></span>
                <span class="check"><i class="fas fa-star"></i></span>
                <span class="check"><i class="fas fa-star"></i></span>
                <span class="check"><i class="fas fa-star"></i></span>
                <span><i class="fas fa-star"></i></span>
                <form action="" method="post">
                   <div class="textarea">
                      <textarea id="add_review" name="add_review" cols="142" rows="4" placeholder="Tell us your opinion"></textarea>
                   </div>
                   <div class="form-button text-c">
                       <input name="submit" id="submit_button" type="button" value="Submit">
                   </div>
                 </form>
             </div>
          </section>
         </div>
      </main>
      <footer>
        <div class="copyright text-c">
           <p><b>&copy;CollegeLink 2021</b></p>
        </div>
        <link href="room_page.css" type="text/css" rel="stylesheet">
        <link rel="stylesheet" href="assets/webfonts/fontall.css">
      </footer>
</html>