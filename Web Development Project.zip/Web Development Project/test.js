let x = document.createElement("h1");
let h = document.createTextNode("Testing JS");
x.appendChild(h);
document.getElementById("rf").appendChild(x);



var slider = document.getElementById("range");
var output = document.getElementById("timi");
output.innerHTML = slider.value;

slider.oninput = function() {
  output.innerHTML = this.value;
}
