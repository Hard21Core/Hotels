<?php

require __DIR__.'/../boot/boot.php';

use Hotel\Room;
// use \DateTime;
use Hotel\RoomType;


//initialize Room service
$room = new Room;

//Get distinct Cities
$cities = $room->getCities();

//Get all areas
$areas = $room->getAreas();

//Get all room types
$type = new RoomType();
$allTypes = $type->getAllTypes(); 

//Get page parameters
$selectedCity = $_REQUEST['city'];
$selectedTypeId = $_REQUEST['room_type'];
$checkInDate = $_REQUEST['check_in_date'];
$checkOutDate = $_REQUEST['check_out_date'];
// print_r($selectedTypeId);die;

//Search for a room
$allAvailableRooms = $room->search(new DateTime($checkInDate), new DateTime($checkOutDate), $selectedCity, $selectedTypeId);



//Get count of guests
$guests = $room->getGuests();

?>


<!DOCTYPE>
<html>
   <head>
     <meta charset="UTF-8">
     <meta name="viewport" content="width=device-width initial-scale=1.0">
     <meta name="robots" content="noindex,nofollow">
     <title>CollegeLink Project|Room Page</title>
   </head>
   <body>
      <header>
         <section class="menu">
           <div class="left_menu">
             <p>Hotels</p>
           </div>
             <div class="right_menu">
                <a href="index.html">
                  <i class="fas fa-home"></i>
                  Home
                </a>
                <div class="profile">
                  <a href="profile.html">
                     <i class="fas fa-user-alt"></i>
                     Profile
                  </a>
                </div>
             </div>
         </section>
      </header>
      <main>
        <div class="container">
           <aside>
             <header>
               <h2 class="text-c">Find the perfect hotel</h2>
             </header>
            <form class="text-c" action="" method="post">
              <div class="form-guests">
                <select id="guests">
                  <option value="null" selected>count of guests</option>
                  <option value="1">1</option>
                  <option value="2">2</option>
                  <option value="3">3</option>
                  <option value="4">4</option>
                </select>
              </div>
              <div class="form-room-type">
                <select id="room_type">
                  <option value="null" selected>Room type</option>
                  <option value="single">single</option>
                  <option value="double">double</option>
                </select>
              </div>
              <div class="form-city">
                <select id="city">
                  <option value="null" selected>city</option>
                </select>
              </div>
              <div class="check-in">
                  <input id="checkin" type="date">
              </div>
              <div class="check-out">
                  <input id="checkout" type="date">
              </div>
              <div class="slider-values">
              <span class="min" style="display:inline-block; float:left;">0€</span>
              <span class="max" style="display:inline-block; float:right;">5000€</span>
            </div>
            <div class="slider">
               <input type="range" min="0" max="5000" value="0" id="range">
               <p>Τιμή: <span id="timi"></span></p>
            </div>
            <div class="form-button">
               <input name="submit" id="submit" type="button" value="find hotel">
            </div>
            </form>
            </aside>
         <section class="hotel-list">
                <header>
                   <h3>My bookings</h3>
                </header>
                <article class="info">
                 <div class="media">
                   <img src="assets/images/room-2.jpg" alt="Image of Grande Britagne's room" height="120px"
                   width="130px">
                 </div>
                 <div class="hotel-info">
                    <h3>Grande Britagne Hotel</h3>
                    <h4>Athens,Syntagma</h4>
                    <p>Το Ξενοδοχείο Μεγάλη Βρετανία βρίσκεται στη καρδιά του ιστορικού κέντρου της Αθήνας, στην Πλατεία Συντάγματος, απέναντι από το Κοινοβούλιο.
                      Προσφέρει εκπληκτική θέα της Ακρόπολης, την οποία μπορεί εύκολα να επισκεφθεί κανείς, το κτίριο της Βουλής και το Καλλιμάρμαρο Στάδιο
                       και είναι σε απόσταση αναπνοής από πολλά μουσεία, καφετέριες, εστιατόρια και εμπορικά καταστήματα της πόλης.
                    </p>
                 <div class="btn">
                    <button>
                       <a href="room_page.html">
                         go to room page
                       </a>
                     </button>
                   </div id="rf">
                 </div>
                 <div class="room-info">
                     <ul>
                       <li><p class="lii">Total cost: 500 €</p></li>
                       <li><p class="lii">Check-in date: 2021-01-09</p></li>
                       <li><p class="lii">Check-out date: 2021-01-15</p></li>
                       <li><p class="lii">Type of room: single room</p></li>
                     </ul>
                 </div>
             </article>
             <article class="info">
              <div class="media">
                <img src="assets/images/room-1.jpg" alt="Image of Grande Britagne's room" height="120px"
                width="130px">
              </div>
              <div class="hotel-info">
                 <h3>Hilton Hotel</h3>
                 <h4>Athens,Zwgrafou</h4>
                 <p>Αυτό το πολυτελές ξενοδοχείο έχει ευρύχωρα δωμάτια και σουίτες με θέα στην πόλη ή την Ακρόπολη, μπαλκόνι και μαρμάρινο μπάνιο με καμπίνα ντους και μπανιέρα.Το ξενοδοχείο στεγάζεται στην εμπορική περιοχή της πόλης, σε απόσταση αναπνοής από την Εθνική Πινακοθήκη, το Μέγαρο Μουσικής και τα καταστήματα του Κολωνακίου. Η Ακρόπολη και η ιστορική περιοχή της Πλάκας βρίσκονται επίσης σε ακτίνα 2,5 χλμ. και 4 χλμ. αντίστοιχα, μακριά. 
                 </p>
              <div class="btn">
                 <button>
                    <a href="room_page.php">
                      go to room page
                    </a>
                  </button>
                </div>
              </div>
              <div class="room-info">
                  <ul>
                    <li><p class="lii">Total cost: 350 €</p></li>
                    <li><p class="lii">Check-in date: 2021-01-09</p></li>
                    <li><p class="lii">Check-out date: 2021-01-15</p></li>
                    <li><p class="lii">Type of room: double room</p></li>
                  </ul>
              </div>
          </article>
         </section>
       </div>
      </main>
      <footer>
        <div class="copyright text-c">
           <p><b>&copy; CollegeLink 2021</b></p>
        </div>
        <link href="list_page.css" type="text/css" rel="stylesheet">
        <link rel="stylesheet" href="assets/webfonts/fontall.css">
      </footer>
      <script src="test.js"></script>
    </body>
</html>